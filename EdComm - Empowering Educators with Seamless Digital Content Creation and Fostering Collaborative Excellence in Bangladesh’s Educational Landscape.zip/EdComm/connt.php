<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "onlineshop";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Escape user inputs for security
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $grade = mysqli_real_escape_string($conn, $_POST['grade']);
    $chapter = mysqli_real_escape_string($conn, $_POST['chapter']);
    $topic = mysqli_real_escape_string($conn, $_POST['topic']);
    $type = mysqli_real_escape_string($conn, $_POST['type']);
    $requirements = mysqli_real_escape_string($conn, $_POST['requirements']);

    // Insert data into database
    $sql = "INSERT INTO form_data (name, email, phone, grade, chapter, topic, type, requirements) 
            VALUES ('$name', '$email', '$phone', '$grade', '$chapter', '$topic', '$type', '$requirements')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>
